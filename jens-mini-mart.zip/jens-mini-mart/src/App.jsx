import { useState, useEffect, useRef } from "react";
import { supabase } from "./supabase";

const G = {
  dark: "#0a1a0d", mid: "#1a3320", card: "#112214", border: "#2a4a2e",
  green: "#2E7D32", bright: "#4CAF50", light: "#81C784", accent: "#A5D6A7",
  text: "#e8f5e9", muted: "#7cb87f", red: "#ef5350", orange: "#FFA726",
  gold: "#FFD54F", white: "#ffffff",
};

const fmt = v => `₱${Number(v).toFixed(2)}`;

const Icon = ({ name, size = 20, color = "currentColor" }) => {
  const icons = {
    scan: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2"><path d="M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2"/><line x1="3" y1="12" x2="21" y2="12"/></svg>,
    home: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9,22 9,12 15,12 15,22"/></svg>,
    box: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>,
    utang: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>,
    chart: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/><line x1="2" y1="20" x2="22" y2="20"/></svg>,
    plus: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>,
    minus: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.5"><line x1="5" y1="12" x2="19" y2="12"/></svg>,
    trash: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2"><polyline points="3,6 5,6 21,6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>,
    edit: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>,
    check: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.5"><polyline points="20,6 9,17 4,12"/></svg>,
    x: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>,
    camera: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>,
    user: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>,
    pay: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>,
    barcode: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2"><path d="M3 5v14M7 5v14M11 5v14M15 5v14M19 5v14M21 5v14"/><rect x="2" y="4" width="20" height="16" rx="1" strokeWidth="1.5" fill="none"/></svg>,
    history: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2"><polyline points="1,4 1,10 7,10"/><path d="M3.51 15a9 9 0 1 0 .49-4.95L1 10"/><polyline points="12,7 12,12 15,15"/></svg>,
    search: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>,
    cart: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>,
    cash: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2"><rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="3"/><path d="M6 12h.01M18 12h.01"/></svg>,
    cloud: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2"><path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"/></svg>,
    refresh: <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2"><polyline points="23,4 23,10 17,10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>,
  };
  return icons[name] || null;
};

const Modal = ({ open, onClose, title, children }) => {
  if (!open) return null;
  return (
    <div style={{ position:"fixed",inset:0,zIndex:100,display:"flex",alignItems:"flex-end",justifyContent:"center",background:"rgba(0,0,0,0.8)" }}>
      <div style={{ background:G.card,border:`1px solid ${G.border}`,borderRadius:"20px 20px 0 0",width:"100%",maxWidth:480,maxHeight:"90vh",overflowY:"auto" }}>
        <div style={{ padding:"16px 20px 14px",borderBottom:`1px solid ${G.border}`,display:"flex",justifyContent:"space-between",alignItems:"center" }}>
          <span style={{ color:G.text,fontWeight:700,fontSize:17 }}>{title}</span>
          <button onClick={onClose} style={{ background:G.mid,border:"none",cursor:"pointer",color:G.muted,padding:6,borderRadius:8,display:"flex" }}>
            <Icon name="x" size={18} color={G.muted}/>
          </button>
        </div>
        <div style={{ padding:20 }}>{children}</div>
      </div>
    </div>
  );
};

const Input = ({ label, value, onChange, type="text", placeholder="", autoFocus=false }) => (
  <div style={{ marginBottom:14 }}>
    {label && <div style={{ color:G.muted,fontSize:11,marginBottom:6,fontWeight:700,letterSpacing:1,textTransform:"uppercase" }}>{label}</div>}
    <input autoFocus={autoFocus} type={type} value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder}
      style={{ width:"100%",background:G.mid,border:`1.5px solid ${G.border}`,borderRadius:10,padding:"11px 14px",color:G.text,fontSize:15,outline:"none",boxSizing:"border-box" }}/>
  </div>
);

const Btn = ({ children, onClick, color=G.green, full=false, small=false, disabled=false, style={} }) => (
  <button onClick={onClick} disabled={disabled}
    style={{ background:disabled?"#1e3a22":color,color:disabled?G.muted:G.white,border:"none",borderRadius:small?8:12,
      padding:small?"8px 14px":"13px 20px",fontWeight:700,fontSize:small?13:15,cursor:disabled?"not-allowed":"pointer",
      width:full?"100%":"auto",display:"flex",alignItems:"center",gap:8,justifyContent:"center",...style }}>
    {children}
  </button>
);

// ─── SCANNER VIEW ────────────────────────────────────────────────────────────
const ScannerView = ({ onScan, onClose }) => {
  const [manualCode, setManualCode] = useState("");
  const [scanning, setScanning] = useState(false);
  const [flash, setFlash] = useState(false);

  const simulateScan = () => {
    setScanning(true); setFlash(true);
    setTimeout(() => setFlash(false), 200);
    setTimeout(() => {
      const codes = ["8850329106217","8850987654321","4901480111162","8934588012934","4800000117001","8998888811001","8850123456789"];
      onScan(codes[Math.floor(Math.random()*codes.length)]);
      setScanning(false);
    }, 1200);
  };

  return (
    <div style={{ position:"fixed",inset:0,zIndex:200,background:"#000",display:"flex",flexDirection:"column" }}>
      <div style={{ flex:1,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",position:"relative" }}>
        <div style={{ background:flash?"rgba(255,255,255,0.25)":"transparent",position:"absolute",inset:0,transition:"background 0.1s",pointerEvents:"none" }}/>
        <div style={{ width:280,height:160,position:"relative",marginBottom:28 }}>
          {[0,1,2,3].map(i=>(
            <div key={i} style={{
              position:"absolute",width:30,height:30,
              ...(i===0?{top:0,left:0}:i===1?{bottom:0,left:0}:i===2?{top:0,right:0}:{bottom:0,right:0}),
              borderTop:i<2?`3px solid ${G.bright}`:"none",borderBottom:i>=2?`3px solid ${G.bright}`:"none",
              borderLeft:i%2===0?`3px solid ${G.bright}`:"none",borderRight:i%2===1?`3px solid ${G.bright}`:"none",
            }}/>
          ))}
          {scanning && <div style={{ position:"absolute",left:8,right:8,height:2,background:`linear-gradient(90deg,transparent,${G.bright},transparent)`,animation:"scanline 1s ease-in-out infinite",top:"50%" }}/>}
          <style>{`@keyframes scanline{0%{top:8%}50%{top:92%}100%{top:8%}}`}</style>
          <div style={{ position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center" }}>
            <Icon name="barcode" size={80} color={scanning?G.bright:"rgba(255,255,255,0.12)"}/>
          </div>
        </div>
        <p style={{ color:"rgba(255,255,255,0.7)",fontSize:14,textAlign:"center",marginBottom:6 }}>
          {scanning?"Scanning...":"Point camera at barcode"}
        </p>
        <p style={{ color:"rgba(255,255,255,0.35)",fontSize:12 }}>Demo mode — simulated barcode</p>
      </div>
      <div style={{ padding:24,gap:12,display:"flex",flexDirection:"column" }}>
        <Btn onClick={simulateScan} disabled={scanning} color={G.green} full>
          <Icon name="camera" size={18} color={G.white}/>{scanning?"Scanning...":"📷 Use Camera (Simulate)"}
        </Btn>
        <div style={{ display:"flex",gap:8 }}>
          <input value={manualCode} onChange={e=>setManualCode(e.target.value)}
            onKeyDown={e=>e.key==="Enter"&&manualCode.trim()&&onScan(manualCode.trim())}
            placeholder="Type barcode manually..."
            style={{ flex:1,background:"rgba(255,255,255,0.1)",border:"1px solid rgba(255,255,255,0.2)",borderRadius:10,padding:"11px 14px",color:"white",fontSize:14,outline:"none" }}/>
          <Btn onClick={()=>manualCode.trim()&&onScan(manualCode.trim())} color={G.green} small>Go</Btn>
        </div>
        <Btn onClick={onClose} color="#1a1a1a" full style={{ border:"1px solid rgba(255,255,255,0.1)" }}>Cancel</Btn>
      </div>
    </div>
  );
};

// ─── MAIN APP ────────────────────────────────────────────────────────────────
export default function App() {
  const [tab, setTab] = useState("pos");
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);
  const [debts, setDebts] = useState([]);
  const [sales, setSales] = useState([]);
  const [scanning, setScanning] = useState(false);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [toast, setToast] = useState(null);

  const [newProductModal, setNewProductModal] = useState(null);
  const [editProductModal, setEditProductModal] = useState(null);
  const [utangModal, setUtangModal] = useState(false);
  const [paymentModal, setPaymentModal] = useState(false);
  const [debtPayModal, setDebtPayModal] = useState(null);
  const [debtHistModal, setDebtHistModal] = useState(null);

  const [newProd, setNewProd] = useState({ name:"", price:"" });
  const [utangName, setUtangName] = useState("");
  const [cashInput, setCashInput] = useState("");
  const [payAmount, setPayAmount] = useState("");
  const [editForm, setEditForm] = useState({});

  // ─── SHOW TOAST ──────────────────────────────────────────────────────────
  const showToast = (msg, color = G.bright) => {
    setToast({ msg, color });
    setTimeout(() => setToast(null), 3000);
  };

  // ─── LOAD ALL DATA FROM SUPABASE ─────────────────────────────────────────
  const loadData = async () => {
    setLoading(true);
    try {
      const [prodRes, debtRes, salesRes] = await Promise.all([
        supabase.from("products").select("*").order("created_at"),
        supabase.from("debts").select("*, debt_history(*)").order("created_at"),
        supabase.from("sales").select("*").order("date", { ascending: false }),
      ]);

      if (prodRes.data)  setProducts(prodRes.data);
      if (debtRes.data)  setDebts(debtRes.data.map(d => ({ ...d, history: d.debt_history || [] })));
      if (salesRes.data) setSales(salesRes.data);
    } catch (e) {
      showToast("⚠️ Dili ma-connect sa database", G.red);
      console.error(e);
    }
    setLoading(false);
  };

  useEffect(() => { loadData(); }, []);
  useEffect(() => { if(editProductModal) setEditForm({name:editProductModal.name,price:String(editProductModal.price)}); },[editProductModal]);

  const cartTotal = cart.reduce((s,i) => s + i.price * i.qty, 0);
  const totalDebt = debts.reduce((s,d) => s + Number(d.balance), 0);
  const todaySales = sales.filter(s=>s.date?.startsWith(new Date().toISOString().slice(0,10))).reduce((s,r)=>s+Number(r.total),0);
  const cash = parseFloat(cashInput)||0;

  // ─── HANDLERS ────────────────────────────────────────────────────────────
  const addToCart = (product) => {
    setCart(prev => {
      const ex = prev.find(i => i.barcode === product.barcode);
      if (ex) return prev.map(i => i.barcode===product.barcode ? {...i,qty:i.qty+1} : i);
      return [...prev, { ...product, qty:1 }];
    });
  };

  const handleScan = (code) => {
    setScanning(false);
    const found = products.find(p => p.barcode === code);
    if (found) { addToCart(found); }
    else { setNewProductModal(code); setNewProd({ name:"", price:"" }); }
  };

  const saveNewProduct = async () => {
    if (!newProd.name || !newProd.price) return;
    setSyncing(true);
    const { data, error } = await supabase
      .from("products")
      .insert({ barcode: newProductModal, name: newProd.name, price: parseFloat(newProd.price) })
      .select()
      .single();

    if (data) {
      setProducts(prev => [...prev, data]);
      addToCart(data);
      showToast("✅ Product saved to cloud!");
    } else {
      showToast("❌ Error saving product", G.red);
      console.error(error);
    }
    setNewProductModal(null);
    setSyncing(false);
  };

  const updateQty = (barcode, delta) =>
    setCart(prev => prev.map(i => i.barcode===barcode ? {...i,qty:Math.max(0,i.qty+delta)} : i).filter(i=>i.qty>0));

  const processCash = async () => {
    setSyncing(true);
    const { data, error } = await supabase
      .from("sales")
      .insert({ items: cart, total: cartTotal, type: "cash", date: new Date().toISOString() })
      .select()
      .single();

    if (data) {
      setSales(prev => [data, ...prev]);
      showToast("✅ Sale recorded!");
    } else {
      showToast("❌ Error saving sale", G.red);
      console.error(error);
    }
    setCart([]); setPaymentModal(false); setCashInput("");
    setSyncing(false);
  };

  const processUtang = async () => {
    if (!utangName.trim()) return;
    setSyncing(true);

    // 1. Save to sales table
    const { data: saleData } = await supabase
      .from("sales")
      .insert({ items: cart, total: cartTotal, type: "utang", date: new Date().toISOString() })
      .select()
      .single();

    if (saleData) setSales(prev => [saleData, ...prev]);

    const ex = debts.find(d => d.name.toLowerCase() === utangName.toLowerCase());

    if (ex) {
      // 2a. Update existing debt balance
      const newBalance = Number(ex.balance) + cartTotal;
      await supabase.from("debts").update({ balance: newBalance }).eq("id", ex.id);

      // 2b. Insert debt_history record
      const histEntry = { debt_id: ex.id, items: cart, total: cartTotal, date: new Date().toISOString() };
      const { data: histData } = await supabase.from("debt_history").insert(histEntry).select().single();

      setDebts(prev => prev.map(d => d.id === ex.id ? {
        ...d,
        balance: newBalance,
        history: [histData || histEntry, ...d.history]
      } : d));
    } else {
      // 3a. Create new debt record
      const { data: debtData } = await supabase
        .from("debts")
        .insert({ name: utangName, balance: cartTotal })
        .select()
        .single();

      if (debtData) {
        // 3b. Insert first debt_history
        const histEntry = { debt_id: debtData.id, items: cart, total: cartTotal, date: new Date().toISOString() };
        const { data: histData } = await supabase.from("debt_history").insert(histEntry).select().single();

        setDebts(prev => [...prev, { ...debtData, history: [histData || histEntry] }]);
      }
    }

    showToast(`✅ Utang ni ${utangName} recorded!`, G.orange);
    setCart([]); setUtangModal(false); setUtangName("");
    setSyncing(false);
  };

  const payDebt = async () => {
    const amt = parseFloat(payAmount);
    if (!amt || amt <= 0) return;
    setSyncing(true);

    const newBalance = Math.max(0, Number(debtPayModal.balance) - amt);

    if (newBalance === 0) {
      await supabase.from("debts").delete().eq("id", debtPayModal.id);
      setDebts(prev => prev.filter(d => d.id !== debtPayModal.id));
      showToast(`✅ ${debtPayModal.name} fully paid!`);
    } else {
      await supabase.from("debts").update({ balance: newBalance }).eq("id", debtPayModal.id);
      setDebts(prev => prev.map(d => d.id === debtPayModal.id ? { ...d, balance: newBalance } : d));
      showToast(`✅ Payment recorded. Remaining: ${fmt(newBalance)}`, G.orange);
    }

    setDebtPayModal(null); setPayAmount("");
    setSyncing(false);
  };

  const saveEdit = async () => {
    if (!editForm.name || !editForm.price) return;
    setSyncing(true);
    await supabase.from("products")
      .update({ name: editForm.name, price: parseFloat(editForm.price) })
      .eq("id", editProductModal.id);

    setProducts(prev => prev.map(p => p.id === editProductModal.id
      ? { ...p, name: editForm.name, price: parseFloat(editForm.price) }
      : p
    ));
    showToast("✅ Product updated!");
    setEditProductModal(null);
    setSyncing(false);
  };

  const deleteProduct = async (id) => {
    await supabase.from("products").delete().eq("id", id);
    setProducts(prev => prev.filter(x => x.id !== id));
    showToast("🗑️ Product deleted", G.red);
  };

  // ─── STYLES ──────────────────────────────────────────────────────────────
  const sApp = { minHeight:"100vh",background:G.dark,color:G.text,fontFamily:"'DM Sans',system-ui,sans-serif",maxWidth:480,margin:"0 auto",position:"relative",paddingBottom:68 };
  const sHeader = { background:G.mid,padding:"14px 16px",borderBottom:`1px solid ${G.border}`,position:"sticky",top:0,zIndex:10 };
  const sNav = { position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",width:"100%",maxWidth:480,background:G.mid,borderTop:`1px solid ${G.border}`,display:"flex",zIndex:50 };
  const sNavBtn = (a) => ({ flex:1,padding:"10px 0 7px",background:"none",border:"none",cursor:"pointer",color:a?G.bright:G.muted,display:"flex",flexDirection:"column",alignItems:"center",gap:3,fontSize:10,fontWeight:a?700:500 });
  const sCard = { background:G.card,border:`1px solid ${G.border}`,borderRadius:14,padding:16,marginBottom:10 };
  const sSection = { padding:"12px 14px 0" };

  // ─── LOADING SCREEN ───────────────────────────────────────────────────────
  if (loading) return (
    <div style={{ ...sApp,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",minHeight:"100vh" }}>
      <div style={{ fontSize:40,marginBottom:16 }}>🏪</div>
      <div style={{ color:G.bright,fontSize:18,fontWeight:700,marginBottom:8 }}>Jen's Mini Mart</div>
      <div style={{ display:"flex",alignItems:"center",gap:8,color:G.muted,fontSize:13 }}>
        <Icon name="cloud" size={16} color={G.muted}/>
        Connecting to cloud...
      </div>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
      <div style={{ marginTop:20,width:24,height:24,border:`2px solid ${G.border}`,borderTop:`2px solid ${G.bright}`,borderRadius:"50%",animation:"spin 0.8s linear infinite" }}/>
    </div>
  );

  // ─── POS TAB ─────────────────────────────────────────────────────────────
  const POSTab = () => {
    const [search, setSearch] = useState("");
    const searchRef = useRef(null);
    const results = search.trim().length > 0
      ? products.filter(p => p.name.toLowerCase().includes(search.toLowerCase()))
      : [];

    return (
      <div style={{ display:"flex",flexDirection:"column",height:"calc(100vh - 68px)",overflow:"hidden" }}>
        <div style={{ ...sHeader,flexShrink:0 }}>
          <div style={{ display:"flex",alignItems:"center",gap:10,marginBottom:12 }}>
            <div style={{ background:G.green,borderRadius:10,width:38,height:38,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0 }}>
              <span style={{ fontSize:18 }}>🏪</span>
            </div>
            <div style={{ flex:1 }}>
              <div style={{ fontWeight:800,fontSize:18,color:G.text,letterSpacing:-0.5 }}>Jen's Mini Mart</div>
              <div style={{ color:G.muted,fontSize:11,display:"flex",alignItems:"center",gap:4 }}>
                <Icon name="cloud" size={10} color={G.bright}/>
                <span style={{ color:G.bright }}>Cloud Sync ON</span>
                {" · "}
                {new Date().toLocaleDateString("en-PH",{month:"short",day:"numeric",year:"numeric"})}
              </div>
            </div>
            <button onClick={()=>setScanning(true)}
              style={{ background:G.green,border:"none",borderRadius:12,padding:"9px 14px",cursor:"pointer",display:"flex",alignItems:"center",gap:6,color:G.white,fontWeight:700,fontSize:13,flexShrink:0 }}>
              <Icon name="camera" size={17} color={G.white}/>
              Scan
            </button>
          </div>

          <div style={{ position:"relative" }}>
            <div style={{ position:"absolute",left:12,top:"50%",transform:"translateY(-50%)",pointerEvents:"none" }}>
              <Icon name="search" size={16} color={G.muted}/>
            </div>
            <input ref={searchRef} value={search} onChange={e=>setSearch(e.target.value)}
              placeholder="Search product by name..."
              style={{ width:"100%",background:G.dark,border:`1.5px solid ${search?G.bright:G.border}`,borderRadius:10,padding:"10px 12px 10px 36px",color:G.text,fontSize:14,outline:"none",boxSizing:"border-box",transition:"border-color 0.2s" }}/>
            {search && (
              <button onClick={()=>setSearch("")} style={{ position:"absolute",right:10,top:"50%",transform:"translateY(-50%)",background:"none",border:"none",cursor:"pointer",padding:2 }}>
                <Icon name="x" size={15} color={G.muted}/>
              </button>
            )}
          </div>

          {results.length > 0 && (
            <div style={{ marginTop:8,background:G.dark,border:`1px solid ${G.bright}44`,borderRadius:10,overflow:"hidden",maxHeight:180,overflowY:"auto" }}>
              {results.map(p=>(
                <button key={p.id} onClick={()=>{ addToCart(p); setSearch(""); }}
                  style={{ width:"100%",background:"none",border:"none",borderBottom:`1px solid ${G.border}`,padding:"10px 14px",cursor:"pointer",display:"flex",justifyContent:"space-between",alignItems:"center",textAlign:"left" }}>
                  <div>
                    <div style={{ color:G.text,fontWeight:600,fontSize:14 }}>{p.name}</div>
                    <div style={{ color:G.muted,fontSize:11,fontFamily:"monospace",marginTop:1 }}>{p.barcode}</div>
                  </div>
                  <div style={{ display:"flex",alignItems:"center",gap:10 }}>
                    <span style={{ color:G.bright,fontWeight:700,fontSize:15 }}>{fmt(p.price)}</span>
                    <div style={{ background:G.green,borderRadius:6,width:26,height:26,display:"flex",alignItems:"center",justifyContent:"center" }}>
                      <Icon name="plus" size={14} color={G.white}/>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
          {search.trim().length > 1 && results.length === 0 && (
            <div style={{ marginTop:8,background:G.dark,border:`1px solid ${G.border}`,borderRadius:10,padding:"12px 14px",display:"flex",justifyContent:"space-between",alignItems:"center" }}>
              <span style={{ color:G.muted,fontSize:13 }}>"{search}" not found</span>
              <Btn onClick={()=>{ setNewProductModal("MANUAL-"+Date.now()); setNewProd({name:search,price:""}); setSearch(""); }} color={G.green} small>
                <Icon name="plus" size={13} color={G.white}/> Add
              </Btn>
            </div>
          )}
        </div>

        <div style={{ flex:1,overflowY:"auto",padding:"10px 14px 0" }}>
          {cart.length === 0 ? (
            <div style={{ textAlign:"center",padding:"40px 20px",color:G.muted }}>
              <div style={{ marginBottom:12,opacity:0.4 }}><Icon name="cart" size={56} color={G.muted}/></div>
              <div style={{ fontSize:15,fontWeight:700,color:G.muted }}>Cart is empty</div>
              <div style={{ fontSize:13,marginTop:4,color:`${G.muted}77` }}>Scan a barcode or search by name above</div>
            </div>
          ) : (
            <>
              <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8 }}>
                <span style={{ color:G.muted,fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:1 }}>
                  {cart.length} item{cart.length!==1?"s":""} · {cart.reduce((s,i)=>s+i.qty,0)} pcs
                </span>
                <button onClick={()=>setCart([])} style={{ background:"none",border:"none",cursor:"pointer",color:G.red,fontSize:12,fontWeight:600,display:"flex",alignItems:"center",gap:4 }}>
                  <Icon name="trash" size={12} color={G.red}/> Clear all
                </button>
              </div>
              {cart.map(item=>(
                <div key={item.barcode} style={{ ...sCard,padding:"12px 14px" }}>
                  <div style={{ display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:8 }}>
                    <div style={{ flex:1 }}>
                      <div style={{ color:G.text,fontWeight:700,fontSize:15 }}>{item.name}</div>
                      <div style={{ color:G.muted,fontSize:11,fontFamily:"monospace",marginTop:1 }}>{item.barcode}</div>
                    </div>
                    <div style={{ color:G.bright,fontWeight:800,fontSize:16,minWidth:80,textAlign:"right" }}>
                      {fmt(item.price * item.qty)}
                    </div>
                  </div>
                  <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center" }}>
                    <span style={{ color:G.muted,fontSize:12 }}>{fmt(item.price)} each</span>
                    <div style={{ display:"flex",alignItems:"center",gap:6 }}>
                      <button onClick={()=>updateQty(item.barcode,-1)}
                        style={{ background:G.mid,border:`1px solid ${G.border}`,borderRadius:7,width:30,height:30,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center" }}>
                        <Icon name="minus" size={13} color={G.text}/>
                      </button>
                      <span style={{ color:G.text,fontWeight:800,fontSize:16,minWidth:22,textAlign:"center" }}>{item.qty}</span>
                      <button onClick={()=>updateQty(item.barcode,1)}
                        style={{ background:G.green,border:"none",borderRadius:7,width:30,height:30,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center" }}>
                        <Icon name="plus" size={13} color={G.white}/>
                      </button>
                      <button onClick={()=>setCart(prev=>prev.filter(i=>i.barcode!==item.barcode))}
                        style={{ background:"rgba(239,83,80,0.12)",border:"none",borderRadius:7,width:30,height:30,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",marginLeft:4 }}>
                        <Icon name="trash" size={13} color={G.red}/>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </>
          )}
        </div>

        <div style={{ flexShrink:0,borderTop:`2px solid ${G.border}`,background:G.mid,padding:14 }}>
          {cart.length > 0 && (
            <div style={{ marginBottom:10,display:"flex",gap:6,flexWrap:"wrap" }}>
              {cart.map(i=>(
                <span key={i.barcode} style={{ background:G.card,color:G.muted,fontSize:11,padding:"2px 8px",borderRadius:20,border:`1px solid ${G.border}` }}>
                  {i.name} ×{i.qty}
                </span>
              ))}
            </div>
          )}
          <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12 }}>
            <div>
              <div style={{ color:G.muted,fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:1 }}>Total</div>
              <div style={{ color:G.bright,fontSize:36,fontWeight:900,letterSpacing:-2,lineHeight:1 }}>{fmt(cartTotal)}</div>
            </div>
            <div style={{ textAlign:"right" }}>
              <div style={{ color:G.muted,fontSize:11 }}>Items</div>
              <div style={{ color:G.text,fontSize:22,fontWeight:800 }}>{cart.reduce((s,i)=>s+i.qty,0)}</div>
            </div>
          </div>
          <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:10 }}>
            <Btn onClick={()=>{ if(cart.length) setPaymentModal(true); }} color={G.green}
              disabled={cart.length===0||syncing} style={{ borderRadius:10,fontSize:14 }}>
              <Icon name="cash" size={16} color={G.white}/> Cash
            </Btn>
            <Btn onClick={()=>{ if(cart.length) setUtangModal(true); }} color={G.orange}
              disabled={cart.length===0||syncing} style={{ borderRadius:10,fontSize:14 }}>
              <Icon name="utang" size={16} color={G.white}/> Utang
            </Btn>
          </div>
        </div>
      </div>
    );
  };

  // ─── HOME TAB ─────────────────────────────────────────────────────────────
  const HomeTab = () => (
    <div>
      <div style={sHeader}>
        <div style={{ display:"flex",alignItems:"center",gap:10,marginBottom:12 }}>
          <div style={{ background:G.green,borderRadius:10,width:40,height:40,display:"flex",alignItems:"center",justifyContent:"center" }}>
            <span style={{ fontSize:20 }}>🏪</span>
          </div>
          <div style={{ flex:1 }}>
            <div style={{ fontWeight:800,fontSize:19,color:G.text }}>Jen's Mini Mart</div>
            <div style={{ color:G.muted,fontSize:12 }}>{new Date().toLocaleDateString("en-PH",{weekday:"long",month:"long",day:"numeric"})}</div>
          </div>
          <button onClick={loadData} style={{ background:G.card,border:`1px solid ${G.border}`,borderRadius:8,padding:"7px 10px",cursor:"pointer",display:"flex",alignItems:"center",gap:5,color:G.muted,fontSize:12 }}>
            <Icon name="refresh" size={13} color={G.muted}/> Sync
          </button>
        </div>
        <div style={{ background:`${G.bright}15`,border:`1px solid ${G.bright}30`,borderRadius:10,padding:"8px 12px",display:"flex",alignItems:"center",gap:8 }}>
          <Icon name="cloud" size={14} color={G.bright}/>
          <span style={{ color:G.bright,fontSize:12,fontWeight:600 }}>Cloud Sync Active — Data shared across all devices</span>
        </div>
      </div>
      <div style={sSection}>
        <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:12 }}>
          {[
            { label:"Today's Sales",val:fmt(todaySales),icon:"chart",color:G.bright },
            { label:"Total Utang",val:fmt(totalDebt),icon:"utang",color:G.orange },
            { label:"Customers w/ Utang",val:debts.length,icon:"user",color:G.accent },
            { label:"Products",val:products.length,icon:"box",color:G.light },
          ].map((stat,i)=>(
            <div key={i} style={{ ...sCard,marginBottom:0,display:"flex",flexDirection:"column",gap:4 }}>
              <div style={{ background:`${stat.color}22`,borderRadius:8,padding:7,display:"flex",width:"fit-content" }}>
                <Icon name={stat.icon} size={16} color={stat.color}/>
              </div>
              <div style={{ color:stat.color,fontSize:22,fontWeight:800,letterSpacing:-1,marginTop:4 }}>{stat.val}</div>
              <div style={{ color:G.muted,fontSize:10,fontWeight:700,textTransform:"uppercase",letterSpacing:0.5 }}>{stat.label}</div>
            </div>
          ))}
        </div>
        <div style={{ ...sCard,marginBottom:12 }}>
          <div style={{ color:G.muted,fontSize:11,fontWeight:700,letterSpacing:1,textTransform:"uppercase",marginBottom:12 }}>Quick Actions</div>
          <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:8 }}>
            <Btn onClick={()=>setTab("pos")} color={G.green} style={{ borderRadius:10,fontSize:14 }}>
              <Icon name="cart" size={16} color={G.white}/> Open POS
            </Btn>
            <Btn onClick={()=>setTab("utang")} color={G.mid} style={{ border:`1px solid ${G.border}`,borderRadius:10,fontSize:14 }}>
              <Icon name="utang" size={16} color={G.orange}/> Utang
            </Btn>
            <Btn onClick={()=>setTab("products")} color={G.mid} style={{ border:`1px solid ${G.border}`,borderRadius:10,fontSize:14 }}>
              <Icon name="box" size={16} color={G.accent}/> Products
            </Btn>
            <Btn onClick={()=>setTab("sales")} color={G.mid} style={{ border:`1px solid ${G.border}`,borderRadius:10,fontSize:14 }}>
              <Icon name="chart" size={16} color={G.light}/> Sales
            </Btn>
          </div>
        </div>
        {sales.length > 0 && (
          <div style={sCard}>
            <div style={{ color:G.muted,fontSize:11,fontWeight:700,letterSpacing:1,textTransform:"uppercase",marginBottom:10 }}>Recent Transactions</div>
            {sales.slice(0,5).map(sale=>(
              <div key={sale.id} style={{ display:"flex",justifyContent:"space-between",padding:"8px 0",borderBottom:`1px solid ${G.border}` }}>
                <div>
                  <div style={{ color:G.text,fontSize:13,fontWeight:600 }}>
                    {sale.items.map(i=>i.name).join(", ").slice(0,28)}{sale.items.map(i=>i.name).join("").length>28?"...":""}
                  </div>
                  <div style={{ color:G.muted,fontSize:11,marginTop:2 }}>{new Date(sale.date).toLocaleTimeString("en-PH",{hour:"2-digit",minute:"2-digit"})}</div>
                </div>
                <div style={{ textAlign:"right" }}>
                  <div style={{ color:sale.type==="utang"?G.orange:G.bright,fontWeight:700,fontSize:14 }}>{fmt(sale.total)}</div>
                  <div style={{ color:G.muted,fontSize:10,textTransform:"uppercase" }}>{sale.type}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );

  // ─── PRODUCTS TAB ─────────────────────────────────────────────────────────
  const ProductsTab = () => {
    const [search, setSearch] = useState("");
    const filtered = products.filter(p=>p.name.toLowerCase().includes(search.toLowerCase()));
    return (
      <div>
        <div style={sHeader}>
          <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12 }}>
            <div style={{ fontWeight:700,fontSize:18,color:G.text }}>Products <span style={{ color:G.muted,fontSize:14,fontWeight:500 }}>({products.length})</span></div>
            <Btn onClick={()=>{setNewProductModal("MANUAL-"+Date.now());setNewProd({name:"",price:""}); }} color={G.green} small>
              <Icon name="plus" size={14} color={G.white}/> Add
            </Btn>
          </div>
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search..."
            style={{ width:"100%",background:G.dark,border:`1.5px solid ${G.border}`,borderRadius:10,padding:"9px 14px",color:G.text,fontSize:14,outline:"none",boxSizing:"border-box" }}/>
        </div>
        <div style={sSection}>
          {filtered.length===0 ? (
            <div style={{ textAlign:"center",padding:"50px 20px",color:G.muted }}>
              <Icon name="box" size={48} color={G.border}/>
              <div style={{ marginTop:12,fontSize:15,fontWeight:600 }}>No products yet</div>
              <div style={{ fontSize:13,marginTop:4,color:`${G.muted}77` }}>Scan a barcode or add manually</div>
            </div>
          ) : filtered.map(p=>(
            <div key={p.id} style={{ ...sCard,display:"flex",justifyContent:"space-between",alignItems:"center" }}>
              <div style={{ flex:1 }}>
                <div style={{ color:G.text,fontWeight:700,fontSize:15 }}>{p.name}</div>
                <div style={{ color:G.muted,fontSize:11,fontFamily:"monospace",marginTop:2 }}>{p.barcode}</div>
              </div>
              <div style={{ display:"flex",alignItems:"center",gap:8 }}>
                <div style={{ color:G.bright,fontWeight:700,fontSize:16,minWidth:70,textAlign:"right" }}>{fmt(p.price)}</div>
                <button onClick={()=>setEditProductModal(p)} style={{ background:G.mid,border:`1px solid ${G.border}`,borderRadius:8,padding:"6px 8px",cursor:"pointer",display:"flex" }}>
                  <Icon name="edit" size={14} color={G.muted}/>
                </button>
                <button onClick={()=>deleteProduct(p.id)} style={{ background:"rgba(239,83,80,0.1)",border:"none",borderRadius:8,padding:"6px 8px",cursor:"pointer",display:"flex" }}>
                  <Icon name="trash" size={14} color={G.red}/>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  // ─── UTANG TAB ────────────────────────────────────────────────────────────
  const UtangTab = () => (
    <div>
      <div style={sHeader}>
        <div style={{ fontWeight:700,fontSize:18,color:G.text,marginBottom:2 }}>Utang List</div>
        <div style={{ color:G.muted,fontSize:13 }}>Total: <span style={{ color:G.orange,fontWeight:700 }}>{fmt(totalDebt)}</span></div>
      </div>
      <div style={sSection}>
        {debts.length===0 ? (
          <div style={{ textAlign:"center",padding:"50px 20px",color:G.muted }}>
            <Icon name="utang" size={48} color={G.border}/>
            <div style={{ marginTop:12,fontSize:15,fontWeight:600 }}>No utang records</div>
          </div>
        ) : debts.map(d=>(
          <div key={d.id} style={sCard}>
            <div style={{ display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10 }}>
              <div style={{ display:"flex",alignItems:"center",gap:10 }}>
                <div style={{ background:`${G.orange}22`,borderRadius:20,width:40,height:40,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0 }}>
                  <Icon name="user" size={18} color={G.orange}/>
                </div>
                <div>
                  <div style={{ color:G.text,fontWeight:700,fontSize:15 }}>{d.name}</div>
                  <div style={{ color:G.muted,fontSize:11 }}>{(d.history||[]).length} purchase{(d.history||[]).length!==1?"s":""}</div>
                </div>
              </div>
              <div style={{ textAlign:"right" }}>
                <div style={{ color:G.orange,fontWeight:800,fontSize:18 }}>{fmt(d.balance)}</div>
                <div style={{ color:G.muted,fontSize:10,textTransform:"uppercase" }}>UNPAID</div>
              </div>
            </div>
            <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:8 }}>
              <Btn onClick={()=>{setDebtPayModal(d);setPayAmount("");}} color={G.green} small>
                <Icon name="pay" size={13} color={G.white}/> Pay
              </Btn>
              <Btn onClick={()=>setDebtHistModal(d)} color={G.mid} small style={{ border:`1px solid ${G.border}` }}>
                <Icon name="history" size={13} color={G.muted}/> History
              </Btn>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  // ─── SALES TAB ────────────────────────────────────────────────────────────
  const SalesTab = () => {
    const totalCash = sales.filter(s=>s.type==="cash").reduce((s,r)=>s+Number(r.total),0);
    const totalUtang = sales.filter(s=>s.type==="utang").reduce((s,r)=>s+Number(r.total),0);
    return (
      <div>
        <div style={sHeader}>
          <div style={{ fontWeight:700,fontSize:18,color:G.text }}>Sales History</div>
        </div>
        <div style={sSection}>
          <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:12 }}>
            {[
              { label:"All Sales",val:fmt(sales.reduce((s,r)=>s+Number(r.total),0)),color:G.bright },
              { label:"Cash",val:fmt(totalCash),color:G.light },
              { label:"Utang",val:fmt(totalUtang),color:G.orange },
            ].map((s,i)=>(
              <div key={i} style={{ background:G.card,border:`1px solid ${G.border}`,borderRadius:12,padding:12 }}>
                <div style={{ color:s.color,fontWeight:800,fontSize:15,letterSpacing:-0.5 }}>{s.val}</div>
                <div style={{ color:G.muted,fontSize:10,fontWeight:700,textTransform:"uppercase",letterSpacing:0.5,marginTop:3 }}>{s.label}</div>
              </div>
            ))}
          </div>
          {sales.length===0 ? (
            <div style={{ textAlign:"center",padding:"50px 20px",color:G.muted }}>
              <Icon name="chart" size={48} color={G.border}/>
              <div style={{ marginTop:12,fontSize:15,fontWeight:600 }}>No sales yet</div>
            </div>
          ) : sales.map(sale=>(
            <div key={sale.id} style={sCard}>
              <div style={{ display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:6 }}>
                <div>
                  <div style={{ color:G.text,fontWeight:700,fontSize:13 }}>{sale.items.map(i=>`${i.name} ×${i.qty}`).join(", ").slice(0,40)}{sale.items.length>2?"...":""}</div>
                  <div style={{ color:G.muted,fontSize:11,marginTop:2 }}>{new Date(sale.date).toLocaleString("en-PH",{month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"})}</div>
                </div>
                <div style={{ textAlign:"right" }}>
                  <div style={{ color:sale.type==="utang"?G.orange:G.bright,fontWeight:800,fontSize:15 }}>{fmt(sale.total)}</div>
                  <div style={{ background:sale.type==="utang"?`${G.orange}22`:`${G.bright}22`,color:sale.type==="utang"?G.orange:G.bright,fontSize:10,fontWeight:700,padding:"2px 7px",borderRadius:20,marginTop:2,textTransform:"uppercase" }}>{sale.type}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  // ─── RENDER ───────────────────────────────────────────────────────────────
  return (
    <div style={sApp}>
      <style>{`*{box-sizing:border-box;margin:0;padding:0}body{background:#0a1a0d}input::placeholder{color:#4a7a4e}::-webkit-scrollbar{width:3px}::-webkit-scrollbar-thumb{background:#2a4a2e;border-radius:2px}@keyframes spin{to{transform:rotate(360deg)}}`}</style>

      {/* TOAST NOTIFICATION */}
      {toast && (
        <div style={{ position:"fixed",top:16,left:"50%",transform:"translateX(-50%)",zIndex:999,background:G.card,border:`1px solid ${toast.color}44`,borderRadius:12,padding:"10px 18px",color:toast.color,fontWeight:700,fontSize:13,whiteSpace:"nowrap",boxShadow:"0 4px 20px rgba(0,0,0,0.5)" }}>
          {toast.msg}
        </div>
      )}

      {/* SYNCING INDICATOR */}
      {syncing && (
        <div style={{ position:"fixed",top:0,left:0,right:0,height:2,background:`linear-gradient(90deg,${G.bright},${G.accent},${G.bright})`,backgroundSize:"200% 100%",animation:"shimmer 1s linear infinite",zIndex:999 }}/>
      )}
      <style>{`@keyframes shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}`}</style>

      {scanning && <ScannerView onScan={handleScan} onClose={()=>setScanning(false)}/>}

      {tab==="pos"      && <POSTab/>}
      {tab==="home"     && <HomeTab/>}
      {tab==="products" && <ProductsTab/>}
      {tab==="utang"    && <UtangTab/>}
      {tab==="sales"    && <SalesTab/>}

      <nav style={sNav}>
        {[
          {id:"pos",icon:"cart",label:"POS"},
          {id:"home",icon:"home",label:"Home"},
          {id:"products",icon:"box",label:"Products"},
          {id:"utang",icon:"utang",label:"Utang"},
          {id:"sales",icon:"chart",label:"Sales"},
        ].map(t=>(
          <button key={t.id} onClick={()=>setTab(t.id)} style={sNavBtn(tab===t.id)}>
            <Icon name={t.icon} size={22} color={tab===t.id?G.bright:G.muted}/>
            <span>{t.label}</span>
          </button>
        ))}
      </nav>

      {/* NEW PRODUCT MODAL */}
      <Modal open={!!newProductModal} onClose={()=>setNewProductModal(null)} title="New Product">
        <div style={{ background:`${G.green}11`,border:`1px solid ${G.green}33`,borderRadius:10,padding:"9px 13px",marginBottom:14,fontFamily:"monospace",fontSize:12,color:G.muted }}>
          {newProductModal}
        </div>
        <Input label="Product Name" value={newProd.name} onChange={v=>setNewProd(p=>({...p,name:v}))} placeholder="e.g. Sardines 555" autoFocus/>
        <Input label="Price (₱)" value={newProd.price} onChange={v=>setNewProd(p=>({...p,price:v}))} type="number" placeholder="0.00"/>
        <Btn onClick={saveNewProduct} color={G.green} full disabled={!newProd.name||!newProd.price||syncing}>
          <Icon name="check" size={16} color={G.white}/> {syncing?"Saving...":"Save & Add to Cart"}
        </Btn>
      </Modal>

      {/* EDIT PRODUCT */}
      <Modal open={!!editProductModal} onClose={()=>setEditProductModal(null)} title="Edit Product">
        <Input label="Name" value={editForm.name||""} onChange={v=>setEditForm(f=>({...f,name:v}))} autoFocus/>
        <Input label="Price (₱)" value={editForm.price||""} onChange={v=>setEditForm(f=>({...f,price:v}))} type="number"/>
        <Btn onClick={saveEdit} color={G.green} full disabled={syncing}>
          <Icon name="check" size={16} color={G.white}/> {syncing?"Saving...":"Save"}
        </Btn>
      </Modal>

      {/* CASH PAYMENT */}
      <Modal open={paymentModal} onClose={()=>setPaymentModal(false)} title="Cash Payment">
        <div style={{ textAlign:"center",marginBottom:16 }}>
          <div style={{ color:G.muted,fontSize:12,marginBottom:4 }}>Total</div>
          <div style={{ color:G.bright,fontSize:40,fontWeight:900,letterSpacing:-2 }}>{fmt(cartTotal)}</div>
        </div>
        <Input label="Cash Received (₱)" value={cashInput} onChange={setCashInput} type="number" placeholder="0.00" autoFocus/>
        {cash>0 && cash>=cartTotal && (
          <div style={{ background:`${G.bright}11`,border:`1px solid ${G.bright}33`,borderRadius:12,padding:"12px 16px",textAlign:"center",marginBottom:14 }}>
            <div style={{ color:G.muted,fontSize:12 }}>Change</div>
            <div style={{ color:G.bright,fontSize:30,fontWeight:900 }}>{fmt(cash-cartTotal)}</div>
          </div>
        )}
        <Btn onClick={processCash} color={G.green} full disabled={cash<cartTotal||syncing}>
          <Icon name="check" size={16} color={G.white}/> {syncing?"Saving...":"Confirm Payment"}
        </Btn>
      </Modal>

      {/* UTANG MODAL */}
      <Modal open={utangModal} onClose={()=>setUtangModal(false)} title="Record as Utang">
        <div style={{ textAlign:"center",marginBottom:14 }}>
          <div style={{ color:G.orange,fontSize:34,fontWeight:900,letterSpacing:-1 }}>{fmt(cartTotal)}</div>
        </div>
        <Input label="Customer Name" value={utangName} onChange={setUtangName} placeholder="Enter name..." autoFocus/>
        {utangName && debts.find(d=>d.name.toLowerCase()===utangName.toLowerCase()) && (
          <div style={{ background:`${G.orange}11`,border:`1px solid ${G.orange}33`,borderRadius:10,padding:"9px 13px",marginBottom:12,fontSize:13,color:G.orange }}>
            Existing — balance: {fmt(debts.find(d=>d.name.toLowerCase()===utangName.toLowerCase())?.balance)}
          </div>
        )}
        <Btn onClick={processUtang} color={G.orange} full disabled={!utangName.trim()||syncing}>
          <Icon name="utang" size={16} color={G.white}/> {syncing?"Saving...":"Confirm Utang"}
        </Btn>
      </Modal>

      {/* PAY DEBT */}
      <Modal open={!!debtPayModal} onClose={()=>setDebtPayModal(null)} title={`Pay — ${debtPayModal?.name}`}>
        <div style={{ textAlign:"center",marginBottom:14 }}>
          <div style={{ color:G.muted,fontSize:12 }}>Balance</div>
          <div style={{ color:G.orange,fontSize:34,fontWeight:900,letterSpacing:-1 }}>{fmt(debtPayModal?.balance||0)}</div>
        </div>
        <Input label="Amount to Pay (₱)" value={payAmount} onChange={setPayAmount} type="number" placeholder="0.00" autoFocus/>
        {parseFloat(payAmount)>0 && (
          <div style={{ background:`${G.bright}11`,border:`1px solid ${G.bright}33`,borderRadius:12,padding:"12px 16px",textAlign:"center",marginBottom:12 }}>
            <div style={{ color:G.muted,fontSize:12 }}>Remaining</div>
            <div style={{ color:parseFloat(payAmount)>=(debtPayModal?.balance||0)?G.bright:G.orange,fontSize:26,fontWeight:900 }}>
              {fmt(Math.max(0,(debtPayModal?.balance||0)-parseFloat(payAmount)))}
            </div>
          </div>
        )}
        <Btn onClick={payDebt} color={G.green} full disabled={!parseFloat(payAmount)||syncing}>
          <Icon name="check" size={16} color={G.white}/> {syncing?"Saving...":"Confirm Payment"}
        </Btn>
      </Modal>

      {/* DEBT HISTORY */}
      <Modal open={!!debtHistModal} onClose={()=>setDebtHistModal(null)} title={`History — ${debtHistModal?.name}`}>
        <div style={{ marginBottom:12 }}>
          <div style={{ color:G.muted,fontSize:11,marginBottom:4 }}>TOTAL BALANCE</div>
          <div style={{ color:G.orange,fontSize:28,fontWeight:900 }}>{fmt(debtHistModal?.balance||0)}</div>
        </div>
        {(debtHistModal?.history||[]).map((h,i)=>(
          <div key={i} style={{ borderBottom:`1px solid ${G.border}`,padding:"10px 0" }}>
            <div style={{ display:"flex",justifyContent:"space-between" }}>
              <div style={{ color:G.text,fontSize:13 }}>{h.items?.map(x=>`${x.name} ×${x.qty}`).join(", ").slice(0,36)}</div>
              <div style={{ color:G.orange,fontWeight:700 }}>{fmt(h.total)}</div>
            </div>
            <div style={{ color:G.muted,fontSize:11,marginTop:3 }}>{new Date(h.date).toLocaleString("en-PH",{month:"short",day:"numeric",year:"numeric",hour:"2-digit",minute:"2-digit"})}</div>
          </div>
        ))}
      </Modal>
    </div>
  );
}
